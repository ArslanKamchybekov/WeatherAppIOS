import Foundation

let json = """
{
  "coord": {
    "lon": -74.006,
    "lat": 40.7143
  },
  "weather": [
    {
      "id": 800,
      "main": "Clear",
      "description": "clear sky",
      "icon": "01d"
    }
  ],
  "base": "stations",
  "main": {
    "temp": 16.77,
    "feels_like": 15.1,
    "temp_min": 15.53,
    "temp_max": 17.76,
    "pressure": 1012,
    "humidity": 23
  },
  "visibility": 10000,
  "wind": {
    "speed": 6.17,
    "deg": 290,
    "gust": 10.29
  },
  "clouds": {
    "all": 0
  },
  "dt": 1679867061,
  "sys": {
    "type": 1,
    "id": 4610,
    "country": "US",
    "sunrise": 1679827789,
    "sunset": 1679872411
  },
  "timezone": -14400,
  "id": 5128581,
  "name": "New York",
  "cod": 200
}
"""

var previewWeather: ResponseBody = decode(json: json)

func decode<T: Decodable>(json: String) -> T {
    guard let data = json.data(using: .utf8) else {
        fatalError("Couldn't convert JSON string to data.")
    }
    do {
        let decoder = JSONDecoder()
        return try decoder.decode(T.self, from: data)
    } catch {
        fatalError("Couldn't parse JSON string as \(T.self):\n\(error)")
    }
}
