import SwiftUI
import CoreLocationUI

struct WelcomeView: View{
    @EnvironmentObject var locationManager: LocationManager
    var body: some View{
        VStack{
            VStack(spacing: 20){
                Image(systemName: "wind.snow.circle.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 80, height: 80)
                Text("Welcome to the Weather App")
                    .bold()
                    .font(.title)
                    .padding()
                VStack(alignment: .leading, spacing: 8){
                    HStack{
                        Image(systemName: "cloud.sun.rain")
                        Text("Get current weather")
                    }
                    HStack{
                        Image(systemName: "paintbrush.pointed")
                        Text("Modern App design")
                    }
                    HStack{
                        Image(systemName: "location.circle")
                        Text("Weather in your city")
                    }
                }
                .padding()
                VStack{
                    Image(systemName: "exclamationmark.brakesignal")
                        .resizable()
                        .foregroundColor(.red)
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 40, height: 40)
                    Text("Please share your current location to get the weather in your area")
                        .padding(10)
                        .foregroundColor(.black)
                }
                .frame(width: 280, height: 130)
                .background(.white)
                .cornerRadius(16)
                .padding()
            }
            .multilineTextAlignment(.center)
            LocationButton(.shareCurrentLocation){
                locationManager.requestLocation()
            }
            .cornerRadius(24)
            .symbolVariant(.fill)
            .foregroundColor(.white)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
